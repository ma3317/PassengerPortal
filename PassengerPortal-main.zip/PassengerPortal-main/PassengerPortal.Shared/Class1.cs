﻿namespace PassengerPortal.Shared;

public class Class1
{

}
