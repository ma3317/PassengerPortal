namespace PassengerPortal.Shared.Models;

public interface ITicketRenderer
{
    void Render(Ticket ticket);
}