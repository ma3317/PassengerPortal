namespace PassengerPortal.Shared.Interfaces;

public interface IUserRepository
{
    
}