namespace PassengerPortal.Shared.Models;

public enum TrainType
{
    Local,
    Express,
    InterCity,
    Night
}