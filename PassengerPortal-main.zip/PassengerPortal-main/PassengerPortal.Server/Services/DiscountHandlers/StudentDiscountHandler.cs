namespace PassengerPortal.Server.Services.DiscountHandlers;

public class StudentDiscountHandler
{
    
}