namespace PassengerPortal.Server.Services.DiscountHandlers;

public class WeekendDiscountHandler
{
    
}