/*namespace PassengerPortal.Server.DiscountStrategies;

public class SeniorDiscountStrategy
{
    
}*/