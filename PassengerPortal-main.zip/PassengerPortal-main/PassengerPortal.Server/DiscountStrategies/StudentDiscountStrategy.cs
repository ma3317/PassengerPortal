/*namespace PassengerPortal.Server.DiscountStrategies;

public class StudentDiscountStrategy : IDiscountStrategy
{
    public decimal ApplyDiscount(decimal basePrice, Passenger passenger, DateTime travelDate)
    {
        if (passenger.IsStudent)
        {
            return basePrice * 0.8m; // 20% zniżki
        }
        return basePrice;
    }
}*/
