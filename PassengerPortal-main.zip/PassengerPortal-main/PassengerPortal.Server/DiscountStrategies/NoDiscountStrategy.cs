/*namespace PassengerPortal.Server.DiscountStrategies
{
    public class NoDiscountStrategy : IDiscountStrategy
    {
        public decimal ApplyDiscount(decimal basePrice, Passenger passenger, DateTime travelDate)
        {
            return basePrice;
        }
    }
}*/